package test

//3. Write a package random with functions nextInt(): Int, nextDouble(): Double, and
//setSeed(seed: Int): Unit. To generate random numbers, use the linear
//congruential generator
//next = previous × a + b mod 2n,
//where a = 1664525, b = 1013904223, and n = 3
package object random {
	private var next = 1
	def nextInt(): Int = {next = (next * 1664525 + 1013904223) % math.pow(2, 32).toInt; next}
	def nextDouble(): Double = nextInt
	def setSeed(seed: Int) = {next = seed;}
}
package test
import scala.beans.BeanProperty
object Exercise4{
}
class Exercise4 {
// 1. Improve the Counter class in Section 5.1, "Simple Classes and Parameterless
// Methods," on page 51 so that it doesn't turn negative at Int.MaxValue.
class Counter {
  private var value = 0
  def increment() { if(value < Int.MaxValue) value += 1 }
  def current = value
  def isLess(other: Counter) = value < other.value // can access private field of other object
}

//2. Write a class BankAccount with methods deposit and withdraw, and a read-only
//property balance.
class BankAccount {
 private var property_balance = 0
	def balance = property_balance
	def deposit(money: Int) = property_balance += money
	def withdraw(money: Int) = if(money < property_balance) property_balance -= money
}

//3. Write a class Time with read-only properties hours and minutes and a method
//before(other: Time): Boolean that checks whether this time comes before the
//other. A Time object should be constructed as new Time(hrs, min), where hrs is in
//military time format (between 0 and 23).

class Time(val hrs: Int, val min: Int) {
	def before(other: Time) = {
		(hrs < other.hrs) || (hrs == other.hrs && min < other.min)
	}
}

//4. Reimplement the Time class from the preceding exercise so that the internal
//representation is the number of minutes since midnight (between 0 and
//24 × 60 – 1). Do not change the public interface. That is, client code should be
//unaffected by your change.

class Time1(hrs: Int, min: Int) {
	private val _time = hrs * 60 + min
	def before(other: Time1) = _time < other._time
}
//5. Make a class Student with read-write JavaBeans properties name (of type String)
//and id (of type Long). What methods are generated? (Use javap to check.) Can
//you call the JavaBeans getters and setters in Scala? Should you?

 class Student(@BeanProperty var name: String, @BeanProperty var id: Int){
 }
// you call the JavaBeans getters and setters in Scala? Ans:Yes Should you? Ans: No
// javap Student
//Compiled from "Student.scala"
//public class Student {
//  public java.lang.String name();
//  public int id();
//  public java.lang.String getName();
//  public int getId();
//  public Student(java.lang.String, int);
//}
// 
 
//6. In the Person class of Section 5.1, “Simple Classes and Parameterless Methods,”
//on page 51, provide a primary constructor that turns negative ages to 0.
 
class Person(var name: String = "", var age: Int = 0) {
	if(age < 0) age = 0
}
 
//7. Write a class Person with a primary constructor that accepts a string containing
//a first name, a space, and a last name, such as new Person("Fred Smith"). Supply
//read-only properties firstName and lastName. Should the primary constructor
//parameter be a var, a val, or a plain parameter? Why?
 
class Person1(name: String) {
	private val fnln = name.split(' ')
	val firstName = fnln(0)
	val lastName = fnln(1)
}

//Should the primary constructor parameter be a var, a val, or a plain parameter? Why? 
//Ans: default parameter is val type,it can't be used to change that value.

//8. Make a class Car with read-only properties for manufacturer, model name,
//and model year, and a read-write property for the license plate. Supply four
//constructors. All require the manufacturer and model name. Optionally,
//model year and license plate can also be specified in the constructor. If not,
//the model year is set to -1 and the license plate to the empty string. Which
//constructor are you choosing as the primary constructor? Why?

class Car(val manufacturer: String, val modelName: String, val modelYear: Int = -1, var licensePlate: String = "") {
	def this(manufacturer: String, modelName: String, licensePlate: String) = {
	  this(manufacturer, modelName, -1, licensePlate)
	}
	
	override def toString = {
	  "[" + manufacturer + ", " + modelName + ", " + modelYear + ", '" + licensePlate + "']"
	}
}

// Which constructor are you choosing as the primary constructor? Why?
// => The constructor that takes all 4 values was chosen as the primary constructor. It's easy to define the other
// constructors that simply need to call the primary constructor with some default values
 
//9. Reimplement the class of the preceding exercise in Java, C#, or C++ (your
//choice). How much shorter is the Scala class?
 
//10. Consider the class
//class Employee(val name: String, var salary: Double) {
// def this() { this("John Q. Public", 0.0) }
//}

//Rewrite it to use explicit fields and a default primary constructor. Which form
//do you prefer? Why?

class Employee(val name: String = "Alekhya Kkaunuri", var salary: Double = .0)


 def join() = {
    val m = new Counter()
    m.isLess(m)
    m.increment
    m.current
    m.increment
    m.current
    var s1 = new Student("Alekhya",0)
    s1.getId //> 0
    s1.id == s1.getId //> true
    s1.name == s1.getName //> true
    s1.setName("Lucy")
    s1.name = "Lucy Derlin"
    s1.getName
    val e1 = new Employee
    //Object Exercise
    Point(3,4)
  }

//Object Exercises:
//--------------

//1. Write an object Conversions with methods inchesToCentimeters, gallonsToLiters, and
//milesToKilometers.
object Conversions{
  def inchesToCentimeters(inches:Double)=2.54*inches
  def gallonsToLiters(gallons:Double)=4.546092*gallons
  def milesToKilometers(miles:Double)=1.609344*miles
}

//2. The preceding problem wasn’t very object-oriented. Provide a general superclass UnitConversion and define objects InchesToCentimeters, GallonsToLiters, and
//MilesToKilometers that extend it.

abstract class UnitConversion{
  def inchesToCentimeters(input: Double): Double
  def gallonsToLiters(gallons:Double): Double
  def milesToKilometers(miles:Double): Double
}

object conversns extends UnitConversion{
  def inchesToCentimeters(inches:Double)=2.54*inches
  def gallonsToLiters(gallons:Double)=4.546092*gallons
  def milesToKilometers(miles:Double)=1.609344*miles
}

//3. Define an Origin object that extends java.awt.Point. Why is this not actually a
//good idea? (Have a close look at the methods of the Point class.)
class Origin extends java.awt.Point {}

//4. Define a Point class with a companion object so that you can construct Point
//instances as Point(3, 4), without using new.
case class Point(x: Int = 0, y: Int = 0) {}
object Point{
  def apply(x: Int, y: Int) = new Point(x, y)
}
//5. Write a Scala application, using the App trait, that prints the command-line
//arguments in reverse order, separated by spaces. For example, scala Reverse
//Hello World should print World Hello.

object Reverse extends App {
  println(args.reverse.mkString(" "))
}

//6. Write an enumeration describing the four playing card suits so that the toString
//method returns ♣, ♦, ♥, or ♠.

//8. Write an enumeration describing the eight corners of the RGB color cube. As
//IDs, use the color values (for example, 0xff0000 for Red).

object RGBCube extends Enumeration {
	val Black = Value(0x000000, "Black")
	val Red = Value(0xff0000, "Red")
	val Green = Value(0x00ff00, "Green")
	val Yellow = Value(0xffff00, "Yellow")
	val Blue = Value(0x0000ff, "Blue")
	val Cyan = Value(0x00ffff, "Cyan")
	val Magenta = Value(0xff00ff, "Magenta")
	val White = Value(0xffffff, "White")
}
}

object CardSuit extends Enumeration {
type CardSuit = Value
  val Hearts = Value("♥")
  val Diamonds = Value("♦")
  val Clubs = Value("♣")
  val Spades = Value("♠")
}



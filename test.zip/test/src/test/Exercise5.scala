package test
//Write an example program to demonstrate that
//package com.horstmann.impatient
//is not the same as
//package com
//package horstmann
//package impatient
package com {
  package horstmann {
    object Utils1 {
      def fulName(name:String) = name
    }
    package impatient {
      class Employee1 {
        def raise(fName:String,sName:String) = Utils1.fulName(fName)
      }
    }
  }
}
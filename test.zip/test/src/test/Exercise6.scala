package test

//2. Write a puzzler that baffles your Scala friends, using a package com that isn’t
//at the top level.

class Exercise6{
  def empName(name:String)={
    com.horstmann.Utils1.fulName(name) // Its not preferable
  }
}
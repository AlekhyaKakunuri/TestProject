package test
import scala.collection.mutable.ArrayBuffer
import scala.io.Source._
import scala.util.matching.Regex
import java.io.PrintWriter
import scala.math._
 import java.io.File
class FilesTest {
  val filename="/home/alekhya/eclipse-workspace/test/src/test/textFile.txt"
//  Write a Scala code snippet that reverses the lines in a file (making the last
//line the first one, and so on).
  def reverseLines={
  fromFile(filename).getLines.toArray.reverse.mkString("\n")
  }
  
// 2. Write a Scala program that reads a file with tabs, replaces each tab with spaces
//so that tab stops are at n-column boundaries, and writes the result to the
//same file.
  
  def tabs2spaces{
   val textWithSpaces =fromFile(filename).mkString.replaceAll("\t", "")
   new PrintWriter(filename) {write(textWithSpaces); close}
}
  
// 3. Write a Scala code snippet that reads a file and prints all words with more
//than 12 characters to the console. Extra credit if you can do this in a single line.
  
  def splttweleve{
    fromFile(filename).mkString.split("\\W+").filter(_.length > 12).foreach(println(_))
  }
  
//  4. Write a Scala program that reads a text file containing only floating-point
//numbers. Print the sum, average, maximum, and minimum of the numbers
//in the file.
  def floatingNumsFile()={
    val regex =  "[0-9]+".r
    val arr = regex.findAllIn(fromFile(filename).mkString).map(_.toFloat).toArray
    val sum=arr.sum
    val maxi=arr.max
    val min=arr.min
    val avg=arr.sum/arr.size
    avg
  }
  
//  5. Write a Scala program that writes the powers of 2 and their reciprocals to a
//file, with the exponent ranging from 0 to 20. Line up the columns:
// 1 1
// 2 0.5
// 4 0.25
// ... ...
  
  def printingPow2{
    new PrintWriter("/home/alekhya/eclipse-workspace/test/src/test/pwrValues.txt") {
        for (i <- 1 to 20) {
         val pow1 =pow(i, 2)
          write(pow1 + "\t" + 1/pow1 +"\n")
       };
      close
      }
  }
  
//6. Make a regular expression searching for quoted strings "like this, maybe with
//\" or \\" in a Java or C++ program. Write a Scala program that prints out all
//such strings in a source file.
 
   def slashStrngs(){
    val regex =  """"((?:(?:\\")|[^"])*)"""".r
    val arr = regex.findAllIn(fromFile(filename).mkString).toArray
    arr.foreach(println(_))
  }
  
//7. Write a Scala program that reads a text file and prints all tokens in the file
//that are not floating-point numbers. Use a regular expression.
   def withoutFloating(){
    val regex =  "[0-9]\\.[0-9]+".r
    val res=fromFile("/home/alekhya/eclipse-workspace/test/src/test/textFile.txt").mkString.split("\\s+").filter(regex.findFirstIn(_)==None)
    res.foreach(println(_))
   }
  
//8. Write a Scala program that prints the src attributes of all img tags of a web
//page. Use regular expressions and groups.
   
   def imgTags(){
     val regex =  """<img([^>]+)src=\"([^\"]+)""".r
     val imgHtm =
  """hello <img src="https://mdn.mozillademos.org/files/12708/image-with-title.png"
     alt="The dinosaur image"
     style="display: block; height: 341px; margin: 0px auto; width: 400px;">
     <img src="img_girl.jpg" alt="Girl in a jacket">"""
    .replace("\n", "")
//     var html = io.Source.fromURL("https://watch.frndlytv.com/on_demand").mkString
     val html=imgHtm.mkString
      val arr = regex.findAllIn(imgHtm).toArray
      arr.foreach(println(_))
   }
  
//9. Write a Scala program that counts how many files with .class extension are
//in a given directory and its subdirectories.
 
    def countClass(dir: File): Int = {
    val dirList = dir.listFiles
    dirList.filter(_.toString.endsWith(".class")).length + dirList.filter(_.isDirectory).map(countClass(_)).sum
  }
  
//10. Expand the example with the serializable Person class that stores a collection
//of friends. Construct a few Person objects, make some of them friends of
//another, and then save an Array[Person] to a file. Read the array back in and
//verify that the friend relations are intact.
}
class Person(val name: String) extends Serializable {
 private val _friends = new ArrayBuffer[Person] // OK—ArrayBuffer is serializable
  def addFriend(p: Person) {_friends += p}
   def getFriends() = _friends.toArray
}

class personSerTest(){
   val p1=new Person("Alekhya")
   val paul = new Person("paul")
   val pierre = new Person("pierre")
   val jacques = new Person("jacques")
    paul.addFriend(pierre)
    pierre.addFriend(paul)
    jacques.addFriend(paul)
    jacques.addFriend(pierre)
    val persons = jacques.getFriends
//    val a=new PrintWriter("/home/alekhya/eclipse-workspace/test/src/test/pwrValues.txt") {
//      for (i <- persons) {
//          write(i +"\n")
//       };close}
    import java.io._
    val out = new ObjectOutputStream(new FileOutputStream("/home/alekhya/eclipse-workspace/test/src/test/pwrValues.txt"))
    out.writeObject(persons)
    out.close()
    val in = new ObjectInputStream(new FileInputStream("/home/alekhya/eclipse-workspace/test/src/test/pwrValues.txt"))
    val savedFred = in.readObject().asInstanceOf[Array[Person]]
    println(savedFred)

}

package test
import scala.math._
import BigInt.probablePrime
import util.Random
import CardSuit._
 import java.io.File
object test {
  def main(args:Array[String]){  
            println(3 - pow(sqrt(3), 2)) 
            println("crazy" * 3)
            println (10 max 2)
            println(BigInt(2) pow 1024)
            println (probablePrime(100, Random))
            println(probablePrime(100, Random).toString(36))
            val s = "String"
            println(s.head)
            println(s(0))
            println(s.last)
            println(s(s.length - 1))
            println("Hello".intersect("World"))
            val name = readLine("Your name: ")
            print("Enter Num: ")
            val num = readInt()
            printf("Hello, %s! Next year, you will be %d.\n", name, num + 1)
            val c=new Package()
            c.test
            println(c.abs(num))
            val b={}
            println(b)
            for(i <- 10 to 1 by -1) println(i)
            c.countdown(num)
            println(c.unicodeProduct(name))
            println(c.product(name))
            println(c.product1(name))
            val c1=new execise2()
            println(c1.matchfn(3,9))
            println(c1.randomRange(10))
            println(c1.swapAdjEle.toList)
            println(c1.forSwapAdjEle.toList)
            println(c1.partitionFun.toList)
            println(c1.avgDoubleArr)
            println(c1.revsortedOrrder.toList)
            println(c1.revsortedOrArBufr.toList)
            println(c1.dupliFund.toList)
            println(c1.dropusng.toList)
            println(c1.americanTz.toList)
            println(c1.datatransfer)
              val c2=new Exercise3()
              println(c2.getDiscount)
              println(c2.readFlemap)
              println(c2.treeMapex)
              println(c2.linkedHashMappex)
              println(c2.getProps)
              val a : Array[Int] = Array(1, 2, 3,9,45,90,50,-4)
              println(c2.minmax(a))
              println(c2.lteqgt(a,9))
              println(c2.zip)
                val c3=new Exercise4()
                println(c3.join)
                println(CardSuit.Hearts)
                println(c.isRed(Spades))
                println(c3.RGBCube.Black.id)
                println("0x%x".format(c3.RGBCube.Red.id))
                val f=new FilesTest()
                println(f.reverseLines)
                f.tabs2spaces
                f.splttweleve
                println(f.floatingNumsFile)
                f.printingPow2
                f.slashStrngs
                f.withoutFloating
                f.imgTags
                println(f.countClass(new File("/home/alekhya/eclipse-workspace/test/src/test")))
                val f1=new personSerTest()
            
    }
}
class Package{
  def test{
    println("hello")
  }
  def abs(x: Double) = if (x > 0) "Positive" else if(x < 0) "Negative" else "Zero"
  def countdown(n: Int){
    for(i <- n to 0 by -1) println(i)
  }
  def unicodeProduct(s: String) = {
  var i = 1
  for (c <- s) i *= c.toInt
  i
}
 def product(s: String) = s.foldLeft(1)(_*_)
 
def product1(s: String): Int = {
 if (s.length == 0) 1
 else s.head * product1(s.tail)
}
// Exercise-4:- 7. Implement a function that checks whether a card suit value from the preceding
//exercise is red.
 def isRed(card: CardSuit) = card == Diamonds || card == Hearts
}